package geometry2d;


public interface Figure {
    float area();
    float perimeter();
    String toString();
}